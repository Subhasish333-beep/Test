import React from 'react';

const Home=()=>{
    return(
        <h1>
            To check th details of todo and todolist click on the respective links
        </h1>
    )
}

export default Home